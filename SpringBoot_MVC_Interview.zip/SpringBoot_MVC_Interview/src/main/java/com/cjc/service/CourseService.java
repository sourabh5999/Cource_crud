package com.cjc.service;

import java.util.List;

import com.cjc.model.Course;

public interface CourseService {
	
	void saveCourse(Course course);
	
	List<Course> viewAllcourse();
	
	List<Course> deleteCourse(int Id);
	
	List<Course> updateCourse(Course course);
	

}
