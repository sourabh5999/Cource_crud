package com.cjc.repository;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.cjc.model.Course;


@Repository
public class CourseDaoIMPL implements CourseDao {

	
    @Autowired
	private SessionFactory factory;
    
	public void saveCourse(Course course) {
		
		System.out.println("------Course in dao layer-------");
		System.out.println(course);
		
	    Session session=factory.openSession();
        session.save(course);
        session.beginTransaction().commit();
		
	}
	public List<Course> getAllCourse() {
		Session session=factory.openSession();
		Transaction tx = session.beginTransaction();
		Query query=session.createQuery("from Course");
		List<Course> list=query.getResultList();
	
		tx.commit();
		return list;
	}
	public List<Course> deleteCourse(int Id) {
		Session session = factory.openSession();
		Transaction tx = session.beginTransaction();
		Query query = session.createQuery("delete from Course where Id=:id");
		query.setParameter("id", Id);
		query.executeUpdate();
		tx.commit();
		return getAllCourse();
	}
	public List<Course> updateCourse(Course course) {
		Session session = factory.openSession();
		Transaction tx = session.beginTransaction();
		session.update(course);
		tx.commit();
		return getAllCourse();
	}
}
