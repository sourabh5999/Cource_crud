package com.cjc.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.cjc.model.Course;
import com.cjc.repository.CourseDao;


public class CourseServiceImpl implements CourseService{
	
	 @Autowired
	    private CourseDao dao;
	
	public void saveCourse(Course course) {
		System.out.println("------Course in service layer-------");
		System.out.println(course);
		dao.saveCourse(course);
	}

	public List<Course> viewAllcourse() {
		return dao.getAllCourse();
				}

	public List<Course> deleteCourse(int Id) {
		return dao.deleteCourse(Id);
	} 

	public List<Course> updateCourse(Course course) {
		return  dao.updateCourse(course);
	}

}
