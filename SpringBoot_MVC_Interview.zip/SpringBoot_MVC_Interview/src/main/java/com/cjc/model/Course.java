package com.cjc.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Course {
	

	@Id
	private int id;
	private String courseName;
	private double fee;
	private String instructor;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getCourseName() {
		return courseName;
	}
	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}
	public double getFee() {
		return fee;
	}
	public void setFee(double fee) {
		this.fee = fee;
	}
	public String getInstructor() {
		return instructor;
	}
	public void setInstructor(String instructor) {
		this.instructor = instructor;
	}
	
	@Override
	public String toString() {
		return "Cource [id=" + id + ", courseName=" + courseName + ", fee=" + fee + ", instructor=" + instructor + "]";
	}
	
	
}
