package com.cjc.repository;

import java.util.List;

import com.cjc.model.Course;


public interface CourseDao {

	void saveCourse(Course course);

	List<Course> getAllCourse();

	List<Course> deleteCourse(int Id);

	List<Course> updateCourse(Course course);

}
