package com.cjc.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cjc.model.Course;
import com.cjc.service.CourseService;



@Controller
public class CourceController {
	
	@Autowired
	public CourseService service;
	
	
	@RequestMapping("/")
	public String landingPage() {
		System.out.println("LandingPange : Called");
		return "index";
	}
	

	@RequestMapping("/courseReg")
	public String saveCourse(@ModelAttribute Course course)
	{
		System.out.println(course);
		service.saveCourse(course);
		return "index";
	}
	
	@RequestMapping("/viewCourse")
	public String viewCourse(Model model) {
		
		List<Course> list=service.viewAllcourse();
		
		model.addAttribute("data",list);
		
		return "success";	

	}
	
	 @RequestMapping("/delete") 
	 public String deleteCourse(@RequestParam int Id,Model model) {
	 
	  List<Course> list=service.deleteCourse(Id);
	  model.addAttribute("data",list);
	  
	  return "success";
	  
	  }
	 
	  @RequestMapping("/up")
	  public String updateCourse(@ModelAttribute Course course,Model model) { 
      
	   List<Course> list= service.updateCourse(course);
	 
       model.addAttribute("data",list);
	  
	   return "success"; 
	   }
	 
}



	
	
	



